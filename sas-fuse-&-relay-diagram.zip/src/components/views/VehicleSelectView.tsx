import React, { useState } from 'react';
import { VehicleModel, Region, FuelType, ActiveView } from '../../types/automotive';
import { Search, Filter, Plus, Check, ShieldCheck, AlertCircle, Car, ArrowRight, Zap, Snowflake } from 'lucide-react';

interface VehicleSelectViewProps {
  vehicles: VehicleModel[];
  activeVehicleId: string;
  onSelectVehicle: (id: string) => void;
  onNavigate: (view: ActiveView) => void;
  onOpenAddModal: () => void;
}

export const VehicleSelectView: React.FC<VehicleSelectViewProps> = ({
  vehicles,
  activeVehicleId,
  onSelectVehicle,
  onNavigate,
  onOpenAddModal,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedRegion, setSelectedRegion] = useState<Region | 'ALL'>('ALL');
  const [selectedFuel, setSelectedFuel] = useState<FuelType | 'ALL'>('ALL');

  const filteredVehicles = vehicles.filter(v => {
    // Search query
    const q = searchQuery.toLowerCase().trim();
    const matchSearch =
      q === '' ||
      v.brand.toLowerCase().includes(q) ||
      v.model.toLowerCase().includes(q) ||
      v.engineCode.toLowerCase().includes(q) ||
      v.variant.toLowerCase().includes(q);

    // Region filter
    const matchRegion = selectedRegion === 'ALL' || v.country === selectedRegion;

    // Fuel filter
    const matchFuel = selectedFuel === 'ALL' || v.fuelType === selectedFuel;

    return matchSearch && matchRegion && matchFuel;
  });

  return (
    <div className="space-y-6 pb-20">
      
      {/* Page Title & Add Button */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h1 className="text-xl sm:text-2xl font-black text-white">
            Pilih Model Kendaraan
          </h1>
          <p className="text-xs sm:text-sm text-slate-400">
            Database global mencakup mobil bensin, diesel, hybrid, PHEV, dan listrik murni dari pabrikan seluruh dunia.
          </p>
        </div>

        <button
          onClick={onOpenAddModal}
          className="px-4 py-2 bg-cyan-600 hover:bg-cyan-500 text-white font-bold rounded-xl text-xs flex items-center gap-1.5 transition shadow-lg shadow-cyan-950/40 self-start sm:self-auto"
        >
          <Plus className="w-4 h-4" />
          <span>Tambah Kendaraan Baru</span>
        </button>
      </div>

      {/* Filter and Search Bar */}
      <div className="p-4 bg-slate-900 border border-slate-800 rounded-2xl shadow-xl space-y-3">
        
        {/* Search input */}
        <div className="relative">
          <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={searchQuery}
            onChange={e => setSearchQuery(e.target.value)}
            placeholder="Cari merek, model, atau kode mesin (contoh: Avanza, 2NR-VE, Ioniq 5, Innova, B48)..."
            className="w-full bg-slate-950 border border-slate-800 rounded-xl pl-10 pr-4 py-2.5 text-xs sm:text-sm text-white placeholder-slate-500 focus:outline-none focus:border-cyan-500"
          />
        </div>

        {/* Region Filter Tabs */}
        <div className="flex items-center gap-1.5 overflow-x-auto pb-1 text-xs">
          <span className="text-[11px] text-slate-400 mr-1 font-semibold whitespace-nowrap">Wilayah:</span>
          {(['ALL', 'JEPANG', 'KOREA', 'EROPA', 'AMERIKA', 'CHINA', 'INDIA'] as const).map(reg => (
            <button
              key={reg}
              onClick={() => setSelectedRegion(reg)}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold whitespace-nowrap transition ${
                selectedRegion === reg
                  ? 'bg-cyan-600 text-white'
                  : 'bg-slate-800/80 text-slate-400 hover:text-white'
              }`}
            >
              {reg === 'ALL' ? 'Semua Wilayah' : reg}
            </button>
          ))}
        </div>

        {/* Powertrain Filter Tabs */}
        <div className="flex items-center gap-1.5 overflow-x-auto pb-1 text-xs border-t border-slate-800/80 pt-2">
          <span className="text-[11px] text-slate-400 mr-1 font-semibold whitespace-nowrap">Powertrain:</span>
          {(
            [
              { key: 'ALL', label: 'Semua Tipe' },
              { key: 'GASOLINE', label: 'Bensin (ICE)' },
              { key: 'DIESEL', label: 'Diesel' },
              { key: 'HEV', label: 'Hybrid (HEV)' },
              { key: 'PHEV', label: 'Plug-in (PHEV)' },
              { key: 'BEV', label: 'Listrik (BEV)' },
            ] as const
          ).map(f => (
            <button
              key={f.key}
              onClick={() => setSelectedFuel(f.key)}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold whitespace-nowrap transition ${
                selectedFuel === f.key
                  ? 'bg-blue-600 text-white'
                  : 'bg-slate-800/80 text-slate-400 hover:text-white'
              }`}
            >
              {f.label}
            </button>
          ))}
        </div>

      </div>

      {/* Vehicle Grid Results */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {filteredVehicles.map(vehicle => {
          const isActive = vehicle.id === activeVehicleId;
          const isEv = vehicle.fuelType === 'BEV' || vehicle.fuelType === 'HEV' || vehicle.fuelType === 'PHEV';

          return (
            <div
              key={vehicle.id}
              className={`relative rounded-2xl border p-5 flex flex-col justify-between transition shadow-lg ${
                isActive
                  ? 'bg-slate-900/90 border-cyan-500/80 shadow-cyan-950/30 ring-1 ring-cyan-500/50'
                  : 'bg-slate-900/70 border-slate-800 hover:border-slate-700 hover:bg-slate-900'
              }`}
            >
              <div>
                
                {/* Header Badge Row */}
                <div className="flex items-center justify-between gap-2 mb-2">
                  <div className="flex items-center gap-1.5">
                    <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-slate-800 text-slate-300 font-bold uppercase">
                      {vehicle.country}
                    </span>
                    <span className={`text-[10px] font-mono px-2 py-0.5 rounded font-bold uppercase ${
                      vehicle.fuelType === 'BEV' ? 'bg-orange-950 text-orange-400 border border-orange-800' :
                      vehicle.fuelType === 'HEV' || vehicle.fuelType === 'PHEV' ? 'bg-blue-950 text-blue-300 border border-blue-800' :
                      vehicle.fuelType === 'DIESEL' ? 'bg-amber-950 text-amber-400 border border-amber-800' :
                      'bg-slate-800 text-slate-300'
                    }`}>
                      {vehicle.fuelType}
                    </span>
                  </div>

                  {/* Status Badge (Requirement H) */}
                  <span className={`text-[10px] font-mono px-2 py-0.5 rounded font-bold uppercase ${
                    vehicle.verificationStatus === 'TERVERIFIKASI' ? 'bg-emerald-950 text-emerald-400 border border-emerald-800' :
                    vehicle.verificationStatus === 'DEMO' ? 'bg-amber-950 text-amber-400 border border-amber-800' :
                    'bg-slate-800 text-slate-400 border border-slate-700'
                  }`}>
                    {vehicle.verificationStatus}
                  </span>
                </div>

                {/* Brand & Model Title */}
                <h3 className="text-lg font-black text-white">
                  {vehicle.brand} {vehicle.model}
                </h3>
                <p className="text-xs text-cyan-400 font-medium">
                  {vehicle.variant} · {vehicle.generation}
                </p>

                {/* Tech Specs */}
                <div className="mt-3 space-y-1 text-xs text-slate-300 border-t border-slate-800/80 pt-2.5">
                  <div className="flex justify-between">
                    <span className="text-slate-400">Tahun Produksi:</span>
                    <span className="font-mono text-slate-200">{vehicle.yearStart} - {vehicle.yearEnd}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-400">Tipe Mesin / Motor:</span>
                    <span className="font-mono text-cyan-300 font-semibold">{vehicle.engineCode}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-400">Transmisi:</span>
                    <span className="text-slate-300">{vehicle.transmission}</span>
                  </div>
                </div>

                {/* Document Reference Info */}
                <div className="mt-3 p-2 bg-slate-950/60 rounded-lg border border-slate-800/80 text-[11px] text-slate-400">
                  <span className="block truncate font-medium text-slate-300">
                    Doc: {vehicle.sourceDocument.docName}
                  </span>
                  <span className="block truncate text-[10px] text-slate-500 font-mono">
                    Ref: {vehicle.sourceDocument.docNumber}
                  </span>
                </div>

              </div>

              {/* Bottom Actions */}
              <div className="mt-4 pt-3 border-t border-slate-800/80 flex items-center justify-between gap-2">
                {isActive ? (
                  <span className="flex items-center gap-1.5 text-xs text-cyan-400 font-bold">
                    <Check className="w-4 h-4 text-cyan-400" />
                    Sedang Aktif
                  </span>
                ) : (
                  <button
                    onClick={() => onSelectVehicle(vehicle.id)}
                    className="px-3.5 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 hover:text-white rounded-lg text-xs font-semibold transition"
                  >
                    Pilih Model Ini
                  </button>
                )}

                <div className="flex items-center gap-1">
                  <button
                    onClick={() => {
                      onSelectVehicle(vehicle.id);
                      onNavigate('fuse_diagram');
                    }}
                    title="Buka Diagram Sekring"
                    className="p-1.5 bg-slate-800 hover:bg-cyan-600 text-slate-300 hover:text-white rounded-lg transition"
                  >
                    <Zap className="w-4 h-4" />
                  </button>
                  <button
                    onClick={() => {
                      onSelectVehicle(vehicle.id);
                      onNavigate(isEv ? 'ev_ac_diagram' : 'ac_diagram');
                    }}
                    title="Buka Diagram Kelistrikan AC"
                    className="p-1.5 bg-slate-800 hover:bg-blue-600 text-slate-300 hover:text-white rounded-lg transition"
                  >
                    <Snowflake className="w-4 h-4" />
                  </button>
                </div>
              </div>

            </div>
          );
        })}
      </div>

      {/* Empty State when no filters match */}
      {filteredVehicles.length === 0 && (
        <div className="p-12 text-center bg-slate-900 border border-slate-800 rounded-2xl">
          <Car className="w-12 h-12 text-slate-600 mx-auto mb-3" />
          <h3 className="text-base font-bold text-white">Tidak ada kendaraan yang sesuai filter</h3>
          <p className="text-xs text-slate-400 mt-1 max-w-sm mx-auto">
            Coba ubah kata kunci pencarian, ganti filter wilayah, atau tambahkan model kendaraan baru ke database lokal.
          </p>
          <button
            onClick={() => {
              setSearchQuery('');
              setSelectedRegion('ALL');
              setSelectedFuel('ALL');
            }}
            className="mt-4 px-4 py-2 bg-slate-800 hover:bg-slate-700 text-cyan-400 text-xs font-semibold rounded-xl"
          >
            Reset Semua Filter
          </button>
        </div>
      )}

    </div>
  );
};
