/**
 * GUN AC – FUSE, RELAY & WIRING DIAGRAM - Core Automotive Technical Types
 * Sesuai Standar OEM (Original Equipment Manufacturer) & ISO/DIN
 */

export type FuelType = 'GASOLINE' | 'DIESEL' | 'HEV' | 'PHEV' | 'BEV';

export type Region = 'JEPANG' | 'KOREA' | 'EROPA' | 'AMERIKA' | 'CHINA' | 'INDIA' | 'LAINNYA';

export type VerificationStatus = 'TERVERIFIKASI' | 'BELUM TERVERIFIKASI' | 'DATA BELUM TERSEDIA' | 'DEMO';

export type FuseBoxLocation = 'ENGINE_BAY' | 'CABIN' | 'REAR' | 'PDU_HV';

export type FuseCategory = 
  | 'AC' 
  | 'ENGINE' 
  | 'LIGHTING' 
  | 'SAFETY' 
  | 'BODY' 
  | 'HV_SYSTEM' 
  | 'AUDIO' 
  | 'TRANSMISSION'
  | 'POWER';

export interface FuseItem {
  id: string;
  boxLocation: FuseBoxLocation;
  code: string;               // e.g. "F14", "10A", "A/C COMP"
  nameOem: string;            // e.g. "A/C COMP", "H-LP RH", "IG2"
  nameId: string;             // e.g. "Kompresor AC & Kopling Magnetik"
  amperage: number;           // 5, 7.5, 10, 15, 20, 25, 30, 40, 50, etc.
  ratingColor: string;        // Hex color according to ISO 8820 standard
  category: FuseCategory;
  functionDesc: string;       // Detailed function in Indonesian
  protectedComponents: string[]; // List of components protected by this fuse
  gridPos: {
    x: number;                // Column index (1-indexed)
    y: number;                // Row index (1-indexed)
    w?: number;               // Width span in cells (default: 1)
    h?: number;               // Height span in cells (default: 1)
    orientation?: 'h' | 'v';
  };
  relatedRelayId?: string;
  wireColorOem?: string;      // e.g. "L-W (Biru/Putih)"
  terminalPin?: string;
  notes?: string;
}

export interface RelayTerminal {
  pinNumber: string;          // e.g. "1", "2", "3", "5" or "85", "86", "30", "87", "87a"
  standardDin?: string;       // DIN 72552 designation
  standardPin?: string;       // Alternative pin label
  nameId: string;             // Terminal description
  wireColorOem: string;       // Wire color code from OEM schematic
  connectedTo: string;        // Target node/component
}

export interface RelayItem {
  id: string;
  boxLocation: FuseBoxLocation;
  code: string;               // e.g. "R01", "MG CLT", "BLOWER"
  nameOem: string;            // e.g. "MAGNETIC CLUTCH RELAY", "A/C BLOWER RELAY"
  nameId: string;             // e.g. "Relay Kopling Magnetik Kompresor AC"
  relayType: '4-PIN SPST' | '5-PIN SPDT' | 'SOLID_STATE' | 'MICRO_ISO';
  terminals: RelayTerminal[];
  coilResistance: string;     // e.g. "120 - 150 Ω @ 20°C"
  contactRating: string;      // e.g. "20A / 14VDC"
  relatedComponents: string[];
  gridPos: {
    x: number;
    y: number;
    w: number;
    h: number;
  };
  functionDesc: string;
  sourceDocRef?: string;
}

export interface SchematicNode {
  id: string;
  labelId: string;            // Indonesian label
  labelOem: string;           // OEM label
  category: 'POWER' | 'FUSE' | 'RELAY' | 'SWITCH' | 'SENSOR' | 'ACTUATOR' | 'ECU' | 'HV_COMPONENT' | 'GROUND' | 'SAFETY';
  partNumber?: string;
  location: string;
  isAcComponent: boolean;
  isHighVoltage: boolean;
  voltageRating?: string;     // e.g. "12V DC", "350V DC", "800V DC"
  description: string;
  connectorPin?: string;
  x: number;                  // SVG schematic coordinate X
  y: number;                  // SVG schematic coordinate Y
}

export interface SchematicWire {
  id: string;
  fromNodeId: string;
  toNodeId: string;
  fromPin?: string;
  toPin?: string;
  oemWireColor: string;       // e.g. "W-B" (White-Black), "L-Y" (Blue-Yellow), "O" (Orange HV)
  oemWireColorName: string;   // e.g. "Putih Garis Hitam", "Oranye HV Berlindung"
  circuitType: 'AC_CABIN' | 'HV_POWER' | 'LV_CONTROL' | 'GROUND' | 'BATTERY_FEED' | 'SIGNAL';
  gauge?: string;             // e.g. "0.5 sq", "0.85 sq", "20 mm²"
  description: string;
}

export interface AcSystemDiagram {
  systemType: 'CONVENTIONAL_ICE' | 'ELECTRIC_BEV_HEV';
  title: string;
  refrigerantType: 'R134a' | 'R1234yf' | 'R744 (CO2)';
  oilType: string;            // e.g. "ND-OIL 8 (PAG 46)", "ND-OIL 11 (POE - Non-Conductive for HV)"
  chargeCapacity: string;     // e.g. "450 ± 20 g"
  nodes: SchematicNode[];
  wires: SchematicWire[];
  operationalSteps: string[];
  troubleshootingChecklist: Array<{ symptom: string; probableCause: string; checkPoints: string }>;
  hvSafetyWarning?: string;
}

export interface VehicleDocumentSource {
  docName: string;            // e.g. "Repair Manual / Wiring Diagram Manual"
  docNumber: string;          // e.g. "RM1124E", "WD-2022-NE", "TSB-SGMW-EV-2023"
  publisher: string;          // e.g. "Toyota Motor Corporation OEM", "Hyundai Motor Global"
  publishYear: string;
  pagesRef: string;           // e.g. "EWD Hal. 142 - 148, Section AC-1"
  verifiedBy?: string;
  verifiedDate?: string;
  documentType: 'OEM_SERVICE_MANUAL' | 'OEM_WIRING_DIAGRAM' | 'TECHNICAL_SERVICE_BULLETIN' | 'OEM_PARTS_CATALOG';
}

export interface VehicleModel {
  id: string;
  brand: string;
  model: string;
  yearStart: number;
  yearEnd: number | 'Present';
  generation: string;
  country: Region;
  fuelType: FuelType;
  engineCode: string;
  engineDisplacement?: string;
  transmission: string;
  variant: string;
  verificationStatus: VerificationStatus;
  sourceDocument: VehicleDocumentSource;
  lastUpdated: string;
  isDemo?: boolean;
  hasEngineBayFuses: boolean;
  hasCabinFuses: boolean;
  hasRelays: boolean;
  hasAcSchematic: boolean;
  hasEvAcSchematic: boolean;
  notes?: string;
  fuses: FuseItem[];
  relays: RelayItem[];
  acDiagram: AcSystemDiagram;
}

export type ActiveView = 
  | 'home'
  | 'vehicle_select'
  | 'fuse_diagram'
  | 'relay_diagram'
  | 'ac_diagram'
  | 'ev_ac_diagram'
  | 'component_list'
  | 'search'
  | 'database_manage'
  | 'references'
  | 'update_sync'
  | 'settings';
